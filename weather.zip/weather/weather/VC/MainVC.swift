//
//  MainVC.swift
//  weather
//
//  Created by Rahul Singh on 9/23/19.
//  Copyright © 2019 Rahul Singh. All rights reserved.
//

import UIKit
import CoreLocation
import SystemConfiguration

class MainVC: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,CLLocationManagerDelegate {
    
    @IBOutlet weak var currentCityLabel: UILabel!
    
    @IBOutlet weak var currentLongLabel: UILabel!
    @IBOutlet weak var currentLatLabel: UILabel!
    @IBOutlet weak var cityPickerView: UIPickerView!
    @IBOutlet weak var searchCityTextField: UITextField!
    @IBOutlet weak var container: UIView!
    var arrayCity = [String]()
    var locationManager: CLLocationManager!
    var currentLat: String = ""
    var currentLong: String = ""
    var weatherTableView: WeatherTableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        // Setup the container
        weatherTableView = Bundle.main.loadNibNamed("WeatherTableView", owner: nil, options: nil)?[0] as? WeatherTableView
        container.addSubview(weatherTableView!)
        weatherTableView!.frame = container.bounds
        
        // To initialise the pull-down-to-refresh from here
        weatherTableView!.initRefreshControl(mainVC: self)
        
        // Array of default cities
        arrayCity = ["Pune","Bangalore","Mumbai","Delhi","Chennai","Gwalior","Guna","Jammu","London"]
        self.cityPickerView.dataSource = self
        self.cityPickerView.delegate = self
        
    }
    
    // MARK: Location Manager
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status != .authorizedWhenInUse {return}
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
        if locationManager.location != nil {
            let locValue: CLLocationCoordinate2D = manager.location!.coordinate
            if (CLLocationCoordinate2DIsValid(locValue)) {
                NSLog("Coordinate valid");
                currentLat = String(format: "%.2f", locValue.latitude)
                currentLong = String(format: "%.2f", locValue.longitude)
                currentLatLabel.text = currentLat
                currentLongLabel.text = currentLong
                getAddressFromLatLon(pdblLatitude: currentLatLabel.text!, withLongitude: currentLongLabel.text!)
            } else {
                NSLog("Coordinate invalid");
            }
        }else {
            NSLog("Not able to get location");
        }
    }
    
    // MARK: Geocoding
    func getLatLongFromAddress(cityName:String){
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(searchCityTextField.text!) {
            placemarks, error in
            let placemark = placemarks?.first
            let lat = placemark?.location?.coordinate.latitude
            let lon = placemark?.location?.coordinate.longitude
            print("Lat: \(String(describing: lat)), Lon: \(String(describing: lon))")
            self.weatherTableView!.initRefreshControl(mainVC: self)
            if lat != nil && lon != nil {
                self.downloadData(lat: String(format: "%.2f", lat!), long: String(format: "%.2f", lon!))
            }else {
                let alert = UIAlertController(title: "Alert", message: "Please enter valid city name.", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    func getAddressFromLatLon(pdblLatitude: String, withLongitude pdblLongitude: String) {
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
        let lat: Double = Double("\(pdblLatitude)")!
        
        let lon: Double = Double("\(pdblLongitude)")!
        
        let ceo: CLGeocoder = CLGeocoder()
        center.latitude = lat
        center.longitude = lon
        
        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        
        
        ceo.reverseGeocodeLocation(loc, completionHandler:
            {(placemarks, error) in
                if (error != nil)
                {
                }
                
                if placemarks != nil
                {
                    
                    let pm = placemarks! as [CLPlacemark]
                    
                    if pm.count > 0 {
                        
                        let pm = placemarks![0]
                        
                        var addressString : String = ""
                        if pm.subLocality != nil {
                            addressString = addressString + pm.subLocality! + ", "
                        }
                        if pm.locality != nil {
                            addressString = addressString + pm.locality! + ", "
                            if pm.country != nil {
                                addressString = addressString + pm.country!
                                self.currentCityLabel.text = addressString
                            }
                            
                        }
                    }
                }
        })
        
    }
    // MARK: API Call
    func downloadData(lat:String,long:String) {
        
        if Reachability.isConnectedToNetwork(){
            // Download the data from OpenWeatherMap
            ApiHandler.getForecast(lat: lat, long: long) { (status, error) in
                
                
                if (error == nil) {
                    self.weatherTableView?.reloadData()
                    
                } else {
                    
                    // If there's an error, let's display the message here
                    let alert = UIAlertController()
                    alert.title = "Check your API Key & Network!"
                    alert.message = error?.localizedDescription
                    let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (alertAction) -> Void in
                        alert.dismiss(animated: true, completion: nil)
                    }
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)
                    
                }
                
            }
        }else {
            let alert = UIAlertController(title: "Alert", message: "Please check network connection.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    @objc func tableViewRefreshRequested() {
        getLatLongFromAddress(cityName: searchCityTextField.text!)
    }
    
    // MARK: IBAction
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        if searchCityTextField.text != "" {
            self.view.endEditing(true)
            getLatLongFromAddress(cityName: searchCityTextField.text!)
        }else {
            
            let alert = UIAlertController(title: "Alert", message: "Please enter city name", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    //MARK: - Pickerview method
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrayCity.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrayCity[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.searchCityTextField.text = arrayCity[row]
    }
}
public class Reachability {
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        
        /* Only Working for WIFI
         let isReachable = flags == .reachable
         let needsConnection = flags == .connectionRequired
         
         return isReachable && !needsConnection
         */
        
        // Working for Cellular and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        
        return ret
        
    }
}
